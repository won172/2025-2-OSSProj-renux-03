export interface AuthNameResponse {
  name: string
}
