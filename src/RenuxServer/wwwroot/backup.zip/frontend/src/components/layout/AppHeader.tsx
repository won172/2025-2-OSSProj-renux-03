interface AppHeaderProps {
  isAuthenticated: boolean
  welcomeMessage: string
  onLogin: () => void
  onSignup: () => void
  onLogout: () => void
}

const AppHeader = ({ isAuthenticated, welcomeMessage, onLogin, onSignup, onLogout }: AppHeaderProps) => {
  return (
    <header>
      <h1>동똑이</h1>
      <nav id="auth-nav">
        {!isAuthenticated ? (
          <div id="guest-view">
            <button id="login-btn" className="auth-btn" type="button" onClick={onLogin}>
              로그인
            </button>
            <button id="signup-btn" className="auth-btn" type="button" onClick={onSignup}>
              회원가입
            </button>
          </div>
        ) : (
          <div id="user-view">
            <span id="welcome-message">{welcomeMessage}</span>
            <button id="logout-btn" className="auth-btn" type="button" onClick={onLogout}>
              로그아웃
            </button>
          </div>
        )}
      </nav>
    </header>
  )
}

export default AppHeader
