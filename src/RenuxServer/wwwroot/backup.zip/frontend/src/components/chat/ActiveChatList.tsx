import { Link } from 'react-router-dom'
import type { ActiveChat } from '../../types/chat'

interface ActiveChatListProps {
  chats: ActiveChat[]
  errorMessage?: string | null
  isAuthenticated: boolean
}

const ActiveChatList = ({ chats, errorMessage, isAuthenticated }: ActiveChatListProps) => {
  const shouldShowSection = chats.length > 0 || Boolean(errorMessage) || isAuthenticated

  if (!shouldShowSection) {
    return null
  }

  return (
    <section id="active-chat-section" className={chats.length > 0 ? '' : 'hidden'}>
      <h2>최근 채팅</h2>
      <ul id="active-chat-list">
        {chats.map((chat) => {
          const fallback = chat.organization?.major?.majorname ?? '이름 없는 채팅'
          const title = chat.title || fallback
          return (
            <li key={chat.id}>
              <Link to={`/chat/${chat.id}`}>{title}</Link>
            </li>
          )
        })}
      </ul>
      {errorMessage && <p className="error-text">{errorMessage}</p>}
      {isAuthenticated && !errorMessage && chats.length === 0 && (
        <p className="secondary-text">최근 채팅이 없습니다.</p>
      )}
    </section>
  )
}

export default ActiveChatList
