import { type FormEvent, useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { apiFetch } from '../../api/client'
import AppHeader from '../../components/layout/AppHeader'
import NewChatSection from '../../components/chat/NewChatSection'
import ActiveChatList from '../../components/chat/ActiveChatList'
import type { Department } from '../../types/organization'
import type { ActiveChat} from '../../types/chat'
import type { AuthNameResponse } from '../../types/auth'
import dongddokiLogo from '../../assets/images/dongddoki-logo.png'

const defaultWelcomeMessage = '환영합니다, 사용자님'

const HomePage = () => {
  const navigate = useNavigate()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userName, setUserName] = useState<string | null>(null)
  const [departments, setDepartments] = useState<Department[]>([])
  const [departmentsLoading, setDepartmentsLoading] = useState(true)
  const [activeChats, setActiveChats] = useState<ActiveChat[]>([])
  const [activeChatsError, setActiveChatsError] = useState<string | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedDepartmentId, setSelectedDepartmentId] = useState('')
  const [chatRoomTitle, setChatRoomTitle] = useState('')
  const [isCreatingChat, setIsCreatingChat] = useState(false)
  const [createChatError, setCreateChatError] = useState<string | null>(null)

  /* 서버 연결 안되어 있을 때 테스트용
   const isNewChatDisabled = false
  */
  const isNewChatDisabled = useMemo(() => {
    if (departmentsLoading) return true
    return departments.length === 0
  }, [departments, departmentsLoading])
  
  /* 서버 연결 안되어 있을 때 테스트용
  useEffect(() => {
    // 서버 미연결 상태 임시 더미 학과
    setDepartments([
      { id: '00000000-0000-0000-0000-000000000001', major: { majorname: '임시 학과 A' } },
      { id: '00000000-0000-0000-0000-000000000002', major: { majorname: '임시 학과 B' } },
    ])
    setDepartmentsLoading(false)
    }, []
    )
  */
  
  useEffect(() => {
    const loadDepartments = async () => {
      setDepartmentsLoading(true)
      try {
        const data = await apiFetch<Department[]>('/req/orgs', { method: 'GET' })
        if (Array.isArray(data)) {
          setDepartments(data)
        } else {
          setDepartments([])
        }
      } catch (error) {
        console.error('Failed to load departments', error)
        setDepartments([])
      } finally {
        setDepartmentsLoading(false)
      }
    }

    loadDepartments()
  }, []
  )
    
  

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const data = await apiFetch<AuthNameResponse>('/auth/name', { method: 'GET' })
        if (data?.name) {
          setIsAuthenticated(true)
          setUserName(data.name)
        }
      } catch (error) {
        console.log('User is not logged in', error)
        setIsAuthenticated(false)
        setUserName(null)
      }
    }

    checkLoginStatus()
  }, [])

  useEffect(() => {
    if (!isAuthenticated) {
      setActiveChats([])
      return
    }

    const fetchActiveChats = async () => {
      try {
        const data = await apiFetch<ActiveChat[]>('/chat/active', { method: 'GET' })
        if (Array.isArray(data)) {
          setActiveChats(data)
          setActiveChatsError(null)
        }
      } catch (error) {
        console.error('Failed to load active chats', error)
        setActiveChats([])
        setActiveChatsError('최근 채팅을 불러오지 못했습니다.')
      }
    }

    fetchActiveChats()
  }, [isAuthenticated])

  useEffect(() => {
    document.body.classList.toggle('modal-open', isModalOpen)
    return () => {
      document.body.classList.remove('modal-open')
    }
  }, [isModalOpen])

  const welcomeMessage = useMemo(() => {
    if (!userName) return defaultWelcomeMessage
    return `환영합니다, ${userName}님`
  }, [userName])

  /*
  const shouldShowChatWindow = useMemo(() => {
    if (!isAuthenticated) return false
    return activeChats.length > 0
  }, [activeChats, isAuthenticated])
  */

  const toggleModal = (open: boolean) => {
    setCreateChatError(null)
    setSelectedDepartmentId('')
    setChatRoomTitle('')
    setIsModalOpen(open)
  }

  const handleNewChatClick = () => {
    toggleModal(true)
  }

  const handleModalClose = () => {
    toggleModal(false)
  }

  const handleCreateChat = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setCreateChatError(null)

    if (!selectedDepartmentId) {
      setCreateChatError('학과를 먼저 선택해주세요.')
      return
    }

    const trimmedTitle = chatRoomTitle.trim()
    if (!trimmedTitle) {
      setCreateChatError('채팅방 제목을 입력해주세요.')
      return
    }

    try {
      setIsCreatingChat(true)
      const chatRoom = await apiFetch<ActiveChat>('/chat/start', {
        method: 'POST',
        json: { orgId: selectedDepartmentId, title: trimmedTitle },
      })
      toggleModal(false)
      navigate(`/chat/${chatRoom.id}`)
    } catch (error) {
      console.error('Failed to create chat room', error)
      setCreateChatError('채팅방을 생성하지 못했습니다. 잠시 후 다시 시도해주세요.')
    } finally {
      setIsCreatingChat(false)
    }
  }

  const handleLogin = () => {
    navigate('/auth/in')
  }

  const handleSignup = () => {
    navigate('/auth/up')
  }

  const handleLogout = async () => {
    try {
      await apiFetch('/auth/signout', { method: 'GET' })
      window.location.reload()
    } catch (error) {
      alert('로그아웃에 실패했습니다. 다시 시도해주세요.')
    }
  }

  const renderBackdrop = () => {
    if (!isModalOpen) return null
    return <div className="modal-backdrop fade show" />
  }

  return (
    <div className="app-container">
      <AppHeader
        isAuthenticated={isAuthenticated}
        welcomeMessage={welcomeMessage}
        onLogin={handleLogin}
        onSignup={handleSignup}
        onLogout={handleLogout}
      />

      <main>
        <aside className="chat-list-container">
          <NewChatSection
            disabled={isNewChatDisabled}
            loading={departmentsLoading}
            hasDepartments={departments.length > 0}
            onNewChat={handleNewChatClick}
          />

          <ActiveChatList chats={activeChats} errorMessage={activeChatsError} isAuthenticated={isAuthenticated} />
        </aside>
        {/*채팅화면*/}
        <section className="chatbot-container">
          {/*{shouldShowChatWindow ? (
            <>
              <div className="chat-window">
                <div className="chat-messages">
                  <div className="message bot">
                    <p>안녕하세요! 무엇을 도와드릴까요?</p>
                  </div>
                </div>
              </div>
              <div className="chat-input-area">
                <input type="text" id="chat-input" placeholder="메시지를 입력하세요..." disabled />
                <button id="send-btn" type="button" disabled>
                  전송
                </button>
              </div>
            </>
          ) : */}
          (
            <div className="chat-placeholder" role="presentation">
              <div className="chat-placeholder-content">
                                  <p>환영합니다</p>
                <div className="chat-placeholder-logo" aria-hidden="true">
                  <img src={dongddokiLogo} alt="동똑이 로고" />
                </div>
                <p className="chat-placeholder-text">새 채팅을 생성하면 상담이 시작됩니다.</p>
              </div>
            </div>
          )
          {/*}*/}
          
        </section>
      </main>

      <div
        className={`modal fade${isModalOpen ? ' show' : ''}`}
        style={{ display: isModalOpen ? 'block' : 'none' }}
        id="new-chat-modal"
        role="dialog"
        aria-modal={isModalOpen}
        aria-hidden={!isModalOpen}
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">새 채팅방 만들기</h5>
              <button
                type="button"
                className="btn-close"
                aria-label="닫기"
                onClick={handleModalClose}
                disabled={isCreatingChat}
              />
            </div>
            <form onSubmit={handleCreateChat}>
              <div className="modal-body">
                <label htmlFor="chat-room-department" className="form-label">
                  학과 선택
                </label>
                <select
                  id="chat-room-department"
                  className="form-select"
                  required
                  value={selectedDepartmentId}
                  onChange={(event) => setSelectedDepartmentId(event.target.value)}
                  disabled={departments.length === 0 || isCreatingChat}
                >
                  <option value="">학과를 선택해주세요.</option>
                  {departments.map((department) => (
                    <option key={department.id} value={department.id}>
                      {department.major?.majorname ?? '알 수 없는 학과'}
                    </option>
                  ))}
                </select>

                <label htmlFor="chat-room-title" className="form-label mt-3">
                  채팅방 제목
                </label>
                <input
                  type="text"
                  id="chat-room-title"
                  className="form-control"
                  placeholder="예: 2024-1 통계학과 상담" 
                  required
                  value={chatRoomTitle}
                  onChange={(event) => setChatRoomTitle(event.target.value)}
                  disabled={isCreatingChat}
                />
                <div className="form-text">선택한 학과 기준으로 새로운 채팅방이 생성됩니다.</div>

                {createChatError && <p className="error-text mt-2">{createChatError}</p>}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={handleModalClose} disabled={isCreatingChat}>
                  취소
                </button>
                <button type="submit" className="btn btn-primary" disabled={isCreatingChat}>
                  {isCreatingChat ? '생성 중...' : '생성'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {renderBackdrop()}
    </div>
  )
}

export default HomePage
