import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { apiFetch } from '../../api/client'
import type { ActiveChat } from '../../types/chat'

interface ChatPageMessage {
  id: string
  isAsk: boolean
  content: string
  createdTime: number
}

const ChatPage = () => {
  const navigate = useNavigate()
  const { chatId } = useParams<{ chatId: string }>()
  const [messages, setMessages] = useState<ChatPageMessage[]>([])
  const [activeChat, setActiveChat] = useState<ActiveChat | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!chatId) {
      navigate('/')
      return
    }

    const loadInitialData = async () => {
      try {
        setLoading(true)
        const messageData = await apiFetch<ChatPageMessage[]>(`/chat/startload?chatId=${chatId}`, {
          method: 'POST',
        })

        if (Array.isArray(messageData)) {
          setMessages(messageData.reverse())
        }

        setActiveChat({ id: chatId, title: null, organization: null })
      } catch (fetchError) {
        console.error('Failed to load chat messages', fetchError)
        setError('채팅을 불러오는 중 문제가 발생했습니다.')
      } finally {
        setLoading(false)
      }
    }

    loadInitialData()
  }, [chatId, navigate])

  const headerTitle = useMemo(() => {
    if (activeChat?.title) return activeChat.title
    return '채팅방'
  }, [activeChat])

  if (!chatId) {
    return null
  }

  return (
    <div className="chat-page">
      <header className="chat-page__header">
        <button type="button" className="chat-page__back" onClick={() => navigate('/')}>
          홈으로
        </button>
        <h1>{headerTitle}</h1>
      </header>

      <main className="chat-page__body">
        {loading ? (
          <p className="chat-page__status">채팅을 불러오는 중...</p>
        ) : error ? (
          <p className="chat-page__status error">{error}</p>
        ) : messages.length === 0 ? (
          <p className="chat-page__status">아직 메시지가 없습니다. 첫 질문을 남겨보세요!</p>
        ) : (
          <ul className="chat-page__messages">
            {messages.map((message) => (
              <li key={message.id} className={`chat-page__message ${message.isAsk ? 'ask' : 'answer'}`}>
                <span>{message.content}</span>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  )
}

export default ChatPage
